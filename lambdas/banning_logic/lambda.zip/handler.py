def handler(event, context):
    print("BANNING LOGIC STUB EVENT:", event)
    return {"status": "ok"}
