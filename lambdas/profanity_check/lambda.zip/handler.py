def handler(event, context):
    print("PROFANITY CHECK STUB EVENT:", event)
    return {"status": "ok"}
