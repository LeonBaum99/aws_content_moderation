from .profanityfilter import ProfanityFilter  # noqa: F401
__version__ = "1.0"
__author__ = "Areeb Beigh <areebbeigh@gmail.com>"
