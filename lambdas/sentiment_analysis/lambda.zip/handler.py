def handler(event, context):
    print("SENTIMENT ANALYSIS STUB EVENT:", event)
    return {"status": "ok"}
